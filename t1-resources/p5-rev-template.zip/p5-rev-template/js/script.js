"use strict";

function setup() {
    console.log("go")

}

function draw() {

}