window.onload = function () {
  console.log("in local storage ex");
};
