class ShapeDef{
    constructor(x,y,shapeClass,customShapeClass,color){
        this.customShapeClass = customShapeClass;
        this.color = color;
        this.shapeClass = shapeClass;
        this.x =x;
        this.y = y;

    }

    // changeClass(newClass){
    //     this.el.classList.remove(this.customShapeClass);
    //     this.customShapeClass = newClass;
    //     //this.el.classList.add(this.customShapeClass);

    // }

}