window.onload = function () {
    console.log("hello json");
}