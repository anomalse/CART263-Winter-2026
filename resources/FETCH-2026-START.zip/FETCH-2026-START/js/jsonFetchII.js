window.onload = goApp;

async function goApp() {
  console.log("hello fetch II");

}
