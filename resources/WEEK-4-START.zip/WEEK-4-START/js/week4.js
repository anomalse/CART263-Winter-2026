window.onload = setup;
function setup() {
  console.log("in week 4 ;)")
}
